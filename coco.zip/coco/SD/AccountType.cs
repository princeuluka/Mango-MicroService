﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coco.SD
{
    public class AccountType
    {
       public enum AccountTypes
        {
            Savings,
            Current
        }
    }
}
